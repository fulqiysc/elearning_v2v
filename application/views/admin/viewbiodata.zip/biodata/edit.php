<div class="col-lg-6">

	<?php

	// echo validation_errors('<div class="alert alert-warning">','</div');

	//error upload
	if (isset($error_upload)) {
		echo '<div class="alert alert-warning">' . $error_upload . '</div>';
	}
	echo form_open_multipart(base_url('admin/biodata/edit/') . $biodata['id_biodata']);
	?>

</div>


<div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">NIK</label>
      <input type="text" name="nik" class="form-control" placeholder="NIK" value="<?= $biodata['nik']; ?>">
       <?= form_error('nik', '<small class="text-danger">', '</small>'); ?>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Nama</label>
      <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?= $biodata['nama']; ?>">
       <?= form_error('nama', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>


 

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Jenis Kelamin</label>
      <select name="jenis_kelamin" class="form-control">
        <option value="Laki-Laki">Laki-Laki</option>
        <option value="Perempuan" <?php if ($biodata['jenis_kelamin'] == "Perempuan") {
											echo "selected";
										} ?>>Perempuan</option>
      </select>
    </div>
  </div>


 <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">TTL</label>
      <input type="text" name="ttl" class="form-control" placeholder="Tempat, Tanggal Lahir dan Tahun" value="<?= $biodata['ttl']; ?>">
       <?= form_error('ttl', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Alamat</label>
      <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?= $biodata['alamat']; ?>">
       <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">RT</label>
      <input type="text" name="rt" class="form-control" placeholder="Rt" value="<?= $biodata['rt']; ?>">
       <?= form_error('rt', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">RW</label>
      <input type="text" name="rw" class="form-control" placeholder="Rw" value="<?= $biodata['rw']; ?>">
       <?= form_error('rw', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



  <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Pendidikan</label>
      <select name="pendidikan" class="form-control">
        <option value="S1" <?php if ($biodata['pendidikan'] == "S1") {
                      echo "selected";
                    } ?>>S1</option>
        <option value="SMA" <?php if ($biodata['pendidikan'] == "SMA") {
											echo "selected";
										} ?>>SMA</option>
        <option value="SMK"<?php if ($biodata['pendidikan'] == "SMK") {
											echo "selected";
										} ?>>SMK</option>
        <option value="SMP" <?php if ($biodata['pendidikan'] == "SMP") {
											echo "selected";
										} ?>>SMP</option>
      </select>
    </div>
  </div>


 <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Golongan Darah</label>
      <input type="text" name="goldar" class="form-control" placeholder="Golongan Darah" value="<?= $biodata['goldar']; ?>">
       <?= form_error('goldar', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>


   <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Nomor HP/WA</label>
      <input type="text" name="hp" class="form-control" placeholder="Nomor HP/WA" value="<?= $biodata['hp']; ?>">
       <?= form_error('hp', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



 <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Facebook</label>
      <input type="text" name="facebook" class="form-control" placeholder="Facebook Account" value="<?= $biodata['facebook']; ?>">

    </div>
  </div>



<div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Email</label>
      <input type="text" name="email" class="form-control" placeholder="Email" value="<?= $biodata['email']; ?>">
 
    </div>
  </div>



<div class="col-lg-4">
	<div class="form-group">

		<label>IMAGE</label>
		<div class="mb-3" style="max-width: 120px;">
			<img src="<?= base_url('assets/biodata/thumbs/') . $biodata['gambar']; ?>" width="100" class="img img-thumbnail">
		</div>
		<input type="file" name="gambar" class="form-control" style="padding-bottom: 40px; padding-top: 10px;">

	</div>
</div>



	<div class="form-group">
		<button type="submit" name="submit" class="btn btn-success">
			<i class="fa fa-save mr-1"></i>Save !
		</button>
		<button type="reset" name="reset" class="btn btn-danger">
			<i class="fa fa-times mr-1"> </i>Reset
		</button>
	</div>
</div>



<?php
//form close

echo form_close();
?>
<div class="col-lg-6">

  <?php

  // echo validation_errors('<div class="alert alert-warning">','</div');

  //error upload
  if (isset($error_upload)) {
    echo '<div class="alert alert-warning">' . $error_upload . '</div>';
  }
  echo form_open_multipart(base_url('admin/biodata/tambah'));
  ?>

</div>


 <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">NIK</label>
      <input type="text" name="nik" class="form-control" placeholder="NIK" value="<?= set_value('nik') ?>">
       <?= form_error('nik', '<small class="text-danger">', '</small>'); ?>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Nama</label>
      <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?= set_value('nama') ?>">
       <?= form_error('nama', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>


  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Jenis Kelamin</label>
      <select name="jenis_kelamin" class="form-control">
        <option value="Laki-Laki">Laki-Laki</option>
        <option value="Perempuan">Perempuan</option>
      </select>
    </div>
  </div>


 <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">TTL</label>
      <input type="text" name="ttl" class="form-control" placeholder="Tempat, Tanggal Lahir dan Tahun" value="<?= set_value('ttl') ?>">
       <?= form_error('ttl', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Alamat</label>
      <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?= set_value('alamat') ?>">
       <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">RT</label>
      <input type="text" name="rt" class="form-control" placeholder="Rt" value="<?= set_value('rt') ?>">
       <?= form_error('rt', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>

  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">RW</label>
      <input type="text" name="rw" class="form-control" placeholder="Rw" value="<?= set_value('rw') ?>">
       <?= form_error('rw', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



  <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Pendidikan</label>
      <select name="pendidikan" class="form-control">
        <option value="S1">S1</option>
        <option value="SMA">SMA</option>
        <option value="SMK">SMK</option>
        <option value="SMP">SMP</option>
      </select>
    </div>
  </div>


 <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Golongan Darah</label>
      <input type="text" name="goldar" class="form-control" placeholder="Golongan Darah" value="<?= set_value('goldar') ?>">
       <?= form_error('goldar', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>


   <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Nomor HP/WA</label>
      <input type="text" name="hp" class="form-control" placeholder="Nomor HP/WA" value="<?= set_value('hp') ?>">
       <?= form_error('hp', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>



 <div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Facebook</label>
      <input type="text" name="facebook" class="form-control" placeholder="Facebook Account" value="<?= set_value('facebook') ?>">

    </div>
  </div>



<div class="col-lg-4">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Email</label>
      <input type="text" name="email" class="form-control" placeholder="Email" value="<?= set_value('email') ?>">
 
    </div>
  </div>




<div class="col-lg-4">
  <div class="form-group">

    <label>Image</label>
    <!-- <div class="mb-3" style="max-width: 120px;"> -->
    <input type="file" name="gambar" class="form-control" style="padding-bottom: 40px; padding-top: 10px;">
    <!--   </div> -->

  </div>
</div>

<!-- 
 <div class="col-lg-4">
  <div class="form-group">

    <label class="font-weight-bold">Kartu Keluarga</label>

    <input type="file" name="kk" class="form-control mt-3" style="padding-bottom: 40px; padding-top: 10px;">

  </div>
</div> -->






<div class="col-lg-6">
  <div class="form-group">
    <button type="submit" name="submit" class="btn btn-success">
      <i class="fa fa-save mr-1"></i>Save !
    </button>
    <button type="reset" name="reset" class="btn btn-danger">
      <i class="fa fa-times mr-1"> </i>Reset
    </button>
  </div>
</div>



<?php
//form close

echo form_close();
?>
<div class="row">
  <div class="col-lg-6">

    <?php
    if ($this->session->flashdata('sukses')) {
      echo '<div class="alert alert-success">';
      echo $this->session->flashdata('sukses');
      echo '</div>';
    }
    ?>

  </div>
</div>


<p>
  <a href="<?= base_url('admin/ktp/tambah') ?>" title="Add User" class="btn btn-success">
    <i class="fa fa-plus"></i>Add New</a>
</p>



<table id="example1" class="table table-bordered table-striped">
  <thead>
    <tr>
      <th>No</th>
      <th>KTP / KK</th>
      <th>Nama</th>
      <th>Date Time</th>
      <th width="16%">Action</th>
    </tr>
  </thead>
  <tbody>

    <?php $i = 1;
    foreach ($ktp as $ktp) { ?>



      <tr>
        <td><?php echo $i ?></td>
        <td><img src="<?= base_url('assets/ktp/thumbs/') . $ktp['ktp']; ?>" width="60" class="img img-thumbnail"></td>
        <td><?php echo $ktp['nama']; ?></td>
        <td><?php echo $ktp['tanggal_post']; ?></td>
        <td>


          <a href="<?= base_url('admin/ktp/edit/') . $ktp['id_ktp']; ?>" title="Edit Berita" class="btn btn-warning btn-sm">
            <i class="fa fa-edit"></i>Edit</a>
          <?php
          include 'delete.php'
          ?>

        </td>
      </tr>



    <?php $i++;
    } ?>
  </tbody>

</table>
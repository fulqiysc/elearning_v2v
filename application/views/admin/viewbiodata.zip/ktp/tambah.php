<div class="col-lg-6">

  <?php

  // echo validation_errors('<div class="alert alert-warning">','</div');

  //error upload
  if (isset($error_upload)) {
    echo '<div class="alert alert-warning">' . $error_upload . '</div>';
  }
  echo form_open_multipart(base_url('admin/ktp/tambah'));
  ?>

</div>




  <div class="col-lg-6">
    <div class="form-group form-group-lg">
      <label class="font-weight-bold">Nama</label>
      <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?= set_value('nama') ?>">
       <?= form_error('nama', '<small class="text-danger">', '</small>'); ?> 
    </div>
  </div>





<div class="col-lg-4">
  <div class="form-group">

    <label>KTP / KK</label>
    <!-- <div class="mb-3" style="max-width: 120px;"> -->
    <input type="file" name="ktp" class="form-control" style="padding-bottom: 40px; padding-top: 10px;">
    <!--   </div> -->

  </div>
</div>







<div class="col-lg-6">
  <div class="form-group">
    <button type="submit" name="submit" class="btn btn-success">
      <i class="fa fa-save mr-1"></i>Save !
    </button>
    <button type="reset" name="reset" class="btn btn-danger">
      <i class="fa fa-times mr-1"> </i>Reset
    </button>
  </div>
</div>



<?php
//form close

echo form_close();
?>